﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AdmonBD.Models
{
    public partial class Usuarios
    {
        public int IdUsuario { get; set; }
        public string Usuario { get; set; }
        public string Contrasena { get; set; }
    }
}
